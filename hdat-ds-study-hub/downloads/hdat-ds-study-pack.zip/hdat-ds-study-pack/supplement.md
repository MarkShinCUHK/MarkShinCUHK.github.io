교육자료 확장 보강 원고

이 원고는 압축을 푼 2025년 교육자료에서 확인한 역량 중 기존 34강에서 설명이나 실습이 부족한 내용을 보완한다. 아래 항목이 모두 공식 HDAT-DS 필수 구현 범위라는 뜻은 아니다. 공식 필수 범위는 별도의 공식 자료 대조표를 따른다. 고전 머신러닝(ML) 실습에는 scikit-learn을, 신경망 구현에는 모두 PyTorch를 사용한다.

# 01. 다중입력·모델 결합·전용 학습루프

## 여러 입력을 합치는 모델과 여러 정답을 내는 모델

교육자료를 바탕으로 확장한 내용이다. 16~19강을 먼저 공부하고, 시퀀스 모델을 다룰 때는 21~22강도 공부한다.

다중입력 모델은 서로 다른 관측을 각각 특징 벡터로 바꾼 뒤 합친다. 예를 들어 이미지와 예측 시점에 이미 측정한 센서를 함께 쓸 수 있다. 반면 출력 헤드(head)가 여러 개인 모델은 공통 특징으로 여러 종류의 정답을 예측한다. 두 구조를 함께 사용할 수도 있다.

가장 먼저 각 입력을 언제 이용할 수 있는지 적는다. 분류 정답을 원-핫(one-hot) 벡터로 바꾸어 입력에 넣으면 정답 누수다. 과거 정답을 특성으로 쓰는 문제도 있지만, 그 정답이 실제 추론 시점에 이미 알려져 있어야 한다. 입력을 늘렸다는 사실만으로 새로운 정보가 추가되지는 않는다.

아래 코드는 이미지와 센서의 특징을 합쳐 3개 클래스의 로짓(logits)과 수치 예측 두 개를 반환한다. 분류 정답은 `[B]` 형태의 long, 회귀 정답은 `[B,2]` 형태의 float다. 클래스 번호를 그대로 회귀 정답으로 사용하면 번호 사이의 거리에 의미가 있다고 가정하게 된다. 여기서는 분류와 별개의 연속 측정값을 회귀 정답으로 사용한다.

```python
import torch
from torch import nn
from torch.nn import functional as F

class SensorImageMultiTask(nn.Module):
    def __init__(self, sensor_features=5, classes=3, targets=2):
        super().__init__()
        self.image_encoder = nn.Sequential(
            nn.Conv2d(3, 8, 3, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(1),
        )
        self.sensor_encoder = nn.Sequential(
            nn.Linear(sensor_features, 6), nn.ReLU(),
        )
        self.shared = nn.Sequential(nn.Linear(14, 12), nn.ReLU())
        self.class_head = nn.Linear(12, classes)
        self.value_head = nn.Linear(12, targets)

    def forward(self, image, sensor):
        if image.ndim != 4 or sensor.ndim != 2:
            raise ValueError("image=[B,3,H,W], sensor=[B,F]가 필요합니다")
        if image.shape[0] != sensor.shape[0]:
            raise ValueError("입력 batch가 다릅니다")
        # [B,8] + [B,6] -> [B,14] -> [B,12]
        h = self.shared(torch.cat([
            self.image_encoder(image), self.sensor_encoder(sensor)
        ], dim=1))
        return self.class_head(h), self.value_head(h)

def multitask_loss(logits, values, class_target, value_target, alpha=0.2):
    if values.shape != value_target.shape:
        raise ValueError("회귀 output-target shape 불일치")
    ce = F.cross_entropy(logits, class_target)
    mse = F.mse_loss(values, value_target)
    return ce + alpha * mse, ce.detach(), mse.detach()

torch.manual_seed(7)
net = SensorImageMultiTask()
optimizer = torch.optim.Adam(net.parameters(), lr=1e-3)
for batch_size in (1, 4):
    image = torch.randn(batch_size, 3, 16, 20)
    sensor = torch.randn(batch_size, 5)
    labels = torch.arange(batch_size) % 3
    targets = torch.randn(batch_size, 2)
    optimizer.zero_grad(set_to_none=True)
    logits, values = net(image, sensor)
    assert logits.shape == (batch_size, 3)
    assert values.shape == targets.shape
    loss, ce, mse = multitask_loss(logits, values, labels, targets)
    assert loss.ndim == 0 and torch.isfinite(loss)
    loss.backward()
    assert net.image_encoder[0].weight.grad is not None
    assert net.sensor_encoder[0].weight.grad is not None
    optimizer.step()
print("다중입력·다중head shape/backward 검사 통과")
```

이 검사는 모델 연결과 역전파가 가능한지 확인한다. 무작위로 만든 합성 정답으로 두 번 학습했다고 예측 성능이 검증된 것은 아니다. 실제 학습에서는 같은 표본 ID의 이미지·센서·정답을 Dataset에서 함께 반환하고 같은 인덱스로 분할한다. 배열마다 따로 순서를 섞으면 같은 표본끼리의 대응이 깨진다. 기존 `(X,y)` 공통 반복문은 다중입력과 여러 출력 헤드를 자동으로 지원하지 않으므로, `image,sensor,class_y,value_y`를 받아 손실을 각각 계산하는 전용 반복문으로 바꾼다.

회귀 정답의 단위가 크면 MSE가 CE보다 훨씬 커져 전체 손실을 좌우할 수 있다. 훈련 데이터의 통계로 정답을 표준화하고 `alpha`는 검증 데이터에서 선택한다. 헤드별 평가지표를 따로 기록하고, 어떤 헤드의 출력을 제출할지와 원래 단위로 어떻게 복원할지도 정한다.

실습: 센서 특성을 5개에서 7개로 바꿀 때 첫 Linear의 입력만 바꾸어라. 이미지 인코더(encoder)의 출력 차원을 8에서 10으로 바꾸면 특징을 합쳐 받는 Linear의 입력 차원은 얼마인가? 회귀 정답 두 열의 단위를 각각 1배, 100배로 바꾸고 손실에 미치는 영향을 비교하라.

<details><summary>해설 보기</summary>

센서 인코더는 계속 특징 6개를 반환하므로 첫 변경에서 두 특징을 합친 차원은 14다. 이미지 특징을 10개로 바꾸면 10+6=16이다. 상대 오차가 같아도 정답의 크기를 100배로 늘리면 제곱오차는 10,000배 커질 수 있다. 단위·정규화·손실 가중치를 고려해야 하는 이유다.

</details>

## CNN과 RNN을 한 모델에서 연결하기

교육자료를 바탕으로 확장한 내용이다. 같은 입력을 CNN과 RNN으로 각각 처리해 특징을 합치는 병렬 구조와, 프레임마다 CNN 특징을 추출해 RNN에 순서대로 넣는 직렬 구조를 구분한다. 병렬 구조는 시간 패턴을 서로 다른 방식으로 추출해 함께 사용한다. 직렬 구조는 이미지의 공간 특징을 먼저 요약한 뒤 프레임 간 변화를 학습한다. 두 구조 모두 정답을 입력으로 사용하지 않는다.

```python
import torch
from torch import nn

class ParallelSensorFusion(nn.Module):
    def __init__(self, features=4, outputs=2):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(features, 8, 3, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )
        self.gru = nn.GRU(features, 6, batch_first=True)
        self.head = nn.Linear(14, outputs)

    def forward(self, x):                    # [B,T,4]
        local = self.cnn(x.transpose(1, 2)).squeeze(-1)  # [B,8]
        _, state = self.gru(x)               # [1,B,6]
        return self.head(torch.cat([local, state[-1]], dim=1))

class FrameSensorGRU(nn.Module):
    def __init__(self, sensors=4, outputs=2):
        super().__init__()
        self.frame_encoder = nn.Sequential(
            nn.Conv2d(3, 8, 3, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(1),
        )
        self.gru = nn.GRU(8 + sensors, 10, batch_first=True)
        self.head = nn.Linear(10, outputs)

    def forward(self, frames, sensors):      # [B,T,3,H,W], [B,T,4]
        b, t, c, h, w = frames.shape
        if sensors.shape[:2] != (b, t):
            raise ValueError("영상과 센서의 batch/time이 다릅니다")
        visual = self.frame_encoder(frames.reshape(b*t, c, h, w))
        visual = visual.reshape(b, t, 8)     # 시간 순서를 유지한다
        merged = torch.cat([visual, sensors], dim=-1)  # [B,T,12]
        _, state = self.gru(merged)          # [1,B,10]
        return self.head(state[-1])          # [B,2]

torch.manual_seed(11)
for b, t in ((1, 3), (4, 6)):
    sensors = torch.randn(b, t, 4)
    frames = torch.randn(b, t, 3, 12, 16)
    for model, inputs in (
        (ParallelSensorFusion(), (sensors,)),
        (FrameSensorGRU(), (frames, sensors)),
    ):
        pred = model(*inputs)
        assert pred.shape == (b, 2) and torch.isfinite(pred).all()
        pred.square().mean().backward()
        assert all(p.grad is not None for p in model.parameters())
print("CNN/RNN 결합 shape/backward 검사 통과")
```

디렉터리에서 영상 파일을 읽은 순서가 라벨 순서와 같다고 보장할 수는 없다. 파일명·측정 시각(timestamp)·카메라 ID를 기록한 목록(manifest)을 기준으로 센서와 연결해야 한다. 앞·좌·우 카메라의 영상을 합칠 때는 모두 같은 시점에 촬영되었는지 검사한다. 움직이는 차량의 인접 프레임은 매우 비슷하므로 프레임을 무작위로 나누기보다 주행 구간이나 시간을 기준으로 분할하는 방식을 검토한다. 원본 영상을 모두 거대한 NumPy 배열로 만들기보다 Dataset이 필요한 프레임만 읽도록 설계한다.

실습: 직렬 모델에서 `[B,T,3,H,W]`를 `[B,3,T,H,W]`로 잘못 바꾸면 어느 단계에서 입력 조건을 어기는가? CNN 특징의 T축을 평균한 뒤 GRU에 넣으면 무엇을 잃는가?

<details><summary>해설 보기</summary>

이 구현은 세 번째 축을 채널로 해석하므로 채널 수를 T로 잘못 읽는다. 우연히 T=3이더라도 축의 의미가 바뀌었으므로 형태 검사만 통과했다고 올바른 입력은 아니다. T축을 먼저 평균하면 프레임 순서가 사라져 GRU에 원래의 시간 변화를 전달할 수 없다.

</details>

## 전용 학습 루프 실습 A · GAN의 두 옵티마이저와 기울기 전달

### 무엇을 배우는 예제인가요?

GAN은 정답 `y` 하나에 대해 모델 하나를 학습하는 구조가 아닙니다. 생성자 G는 잡음(noise)을 받아 가짜 데이터를 만들고, 판별자 D는 진짜와 가짜를 구별합니다. 따라서 `(X,y)`와 옵티마이저(optimizer) 하나를 받는 공통 지도학습 함수를 그대로 사용할 수 없습니다. 아래는 **두 모델의 교대 학습이 올바르게 이루어지는지 확인하는 2차원 합성 예제**입니다. 실제 문제에 GAN을 반드시 사용하라는 뜻은 아닙니다.

한 번의 반복에서 다음 두 번의 갱신을 구분합니다.

- D 단계: 진짜에는 1, 가짜에는 0을 붙입니다. `G(z).detach()`로 G까지 이어지는 미분 계산을 끊고 D만 갱신합니다.
- G 단계: D가 가짜를 진짜로 판단하도록 목표를 1로 둡니다. 이번에는 **G 출력에 detach를 적용하면 안 됩니다.** D의 파라미터는 고정하되, D 연산을 거쳐 G의 파라미터까지 기울기를 계산할 수 있어야 합니다.

D는 확률이 아니라 변환 전 로짓 하나를 반환합니다. `BCEWithLogitsLoss`에 sigmoid가 포함되어 있기 때문입니다. 이 예제의 진짜 데이터는 `[-1,1]` 범위이고, G의 마지막 `Tanh`도 같은 범위를 출력합니다. 실제 데이터가 `[0,1]` 범위이거나 표준화된 제한 없는 연속값이라면 출력 활성함수와 전처리도 그 범위에 맞춰 다시 정합니다.

### 코드를 복사해 두 번 갱신하기

```python
import torch
from torch import nn

torch.manual_seed(17)
device = torch.device("cpu")
G = nn.Sequential(nn.Linear(3, 8), nn.ReLU(), nn.Linear(8, 2), nn.Tanh()).to(device)
D = nn.Sequential(nn.Linear(2, 8), nn.LeakyReLU(0.2), nn.Linear(8, 1)).to(device)
g_opt = torch.optim.Adam(G.parameters(), lr=1e-3)
d_opt = torch.optim.Adam(D.parameters(), lr=1e-3)
bce = nn.BCEWithLogitsLoss()

def check_gradients(module):
    assert all(p.grad is not None and torch.isfinite(p.grad).all()
               for p in module.parameters())

G.train()
D.train()
for step in range(2):
    # 합성 real: 두 점 주변의 작은 구름. 실제 데이터 계약의 대체물이 아닙니다.
    side = torch.randint(0, 2, (16, 1), device=device).float() * 2 - 1
    real = (0.5 * side + 0.1 * torch.randn(16, 2, device=device)).clamp(-1, 1)
    assert real.shape == (16, 2) and real.min() >= -1 and real.max() <= 1

    # 1. D 갱신: G의 graph를 끊습니다. 지난 G gradient도 지워 검사합니다.
    g_opt.zero_grad(set_to_none=True)
    d_opt.zero_grad(set_to_none=True)
    fake_for_d = G(torch.randn(16, 3, device=device)).detach()
    real_logit, fake_logit = D(real), D(fake_for_d)
    d_loss = (bce(real_logit, torch.ones_like(real_logit))
              + bce(fake_logit, torch.zeros_like(fake_logit))) / 2
    assert torch.isfinite(d_loss)
    d_loss.backward()
    check_gradients(D)
    assert all(p.grad is None for p in G.parameters())  # D 단계에서 G로 역전파 안 됨
    d_opt.step()

    # 2. G 갱신: D parameter는 고정하지만 D 연산의 autograd는 유지합니다.
    d_opt.zero_grad(set_to_none=True)
    for p in D.parameters():
        p.requires_grad_(False)
    g_opt.zero_grad(set_to_none=True)
    fake_for_g = G(torch.randn(16, 3, device=device))  # detach 금지
    fooled_logit = D(fake_for_g)                    # no_grad/inference_mode 금지
    g_loss = bce(fooled_logit, torch.ones_like(fooled_logit))
    assert torch.isfinite(g_loss)
    g_loss.backward()
    check_gradients(G)
    assert all(p.grad is None for p in D.parameters())
    g_opt.step()
    for p in D.parameters():
        p.requires_grad_(True)  # 다음 D 단계에서 다시 학습
    assert all(torch.isfinite(p).all() for p in list(G.parameters()) + list(D.parameters()))
    print(f"step={step + 1} D_loss={d_loss.item():.4f} G_loss={g_loss.item():.4f}")

G.eval()
with torch.inference_mode():
    sample = G(torch.randn(5, 3, device=device))
assert sample.shape == (5, 2) and torch.isfinite(sample).all()
assert (sample >= -1).all() and (sample <= 1).all()
print("GAN 연결 검사 통과: shape·유한값·D/G gradient 경로")
```

### 해설과 재도전

`requires_grad_(False)`는 D의 파라미터에 대한 기울기 계산을 막지만 입력에 대한 미분까지 막지는 않습니다. 그래서 G 단계에서도 D 연산을 거쳐 계산한 기울기로 G를 갱신할 수 있습니다. 반면 D 호출을 `torch.no_grad()`로 감싸거나 `fake_for_g.detach()`를 쓰면 G를 학습할 기울기를 계산할 수 없습니다. D 단계에서 detach를 지우면 현재 코드의 “G 기울기가 없어야 한다” 검사가 실패합니다. 두 가지를 각각 바꿔 보고 왜 서로 다른 단계에서 실패하는지 설명한 뒤 원래대로 되돌리세요.

이 작은 D/G에는 BatchNorm이나 Dropout이 없습니다. 그런 층을 추가하면 파라미터를 고정해도 누적 통계(running statistics)와 드롭아웃 동작까지 고정되지는 않습니다. 각 단계에서 `train()/eval()`을 어떻게 설정할지도 따로 정해야 합니다. 또한 `eval()`만으로 기울기 계산이 꺼지지는 않습니다.

통과 기준은 **두 옵티마이저가 올바르게 연결되어 있고, D 단계에서는 G의 기울기 계산이 차단되며, G 단계에서는 G의 기울기가 유한하게 계산되는 것**입니다. 손실이 유한하거나 한 번 감소했다고 생성 품질·다양성이나 모드 붕괴(mode collapse)의 해결을 입증할 수는 없습니다. 두 번만 갱신하는 예제이므로 진짜 데이터의 분포를 학습했다고 해석하지 마세요. 실제 생성 품질은 별도의 방법으로 검증해야 합니다.

## 전용 학습 루프 실습 B · 잡음 제거 AE의 오염된 입력과 원본 정답

### 일반 Autoencoder와 무엇이 다른가요?

일반 오토인코더(Autoencoder, AE)의 기본 실습은 `clean → clean` 복원입니다. 잡음 제거 오토인코더(Denoising AE)는 학습 입력에 잡음을 추가하되 정답은 잡음 없는 원본으로 유지하는 **`noisy → clean`** 학습입니다. `noisy → noisy`를 학습하면 원래 신호를 복원하라는 목표를 주지 않은 것입니다.

G/D 두 모델이 필요한 GAN과 달리 잡음 제거 AE에는 모델과 옵티마이저가 하나씩 필요합니다. **잡음을 넣은 입력과 원본 정답을 미리 준비했다면** 공통 지도학습 반복문에도 연결할 수 있습니다. 다만 아래에서는 매번 새 잡음을 만드는 증강, 원본 정답의 보존, 검증용 잡음의 고정을 명확하게 제어하기 위해 짧은 전용 반복문을 사용합니다. 모든 AE 문제에서 잡음 제거를 요구하는 것은 아닙니다.

### 코드를 복사해 두 번 갱신하기

```python
import torch
from torch import nn

torch.manual_seed(23)
device = torch.device("cpu")

# 같은 합성 생성 규칙으로 독립 train/valid 샘플을 만듭니다.
# projection은 데이터 생성 규칙이며 valid에서 학습한 전처리 통계가 아닙니다.
projection = torch.randn(2, 6, device=device)
def make_clean(n):
    return torch.tanh(torch.randn(n, 2, device=device) @ projection)

clean_train = make_clean(32)
clean_valid = make_clean(12)
clean_before = clean_train.clone()
noise_std = 0.15
def corrupt(clean):
    # 원본에 in-place로 더하지 않습니다. clean 정답을 그대로 보존합니다.
    return (clean + noise_std * torch.randn_like(clean)).clamp(-1, 1)

# 모델 비교 기준이 noise 재추첨 때문에 흔들리지 않도록 한 번 만들고 고정합니다.
noisy_valid = corrupt(clean_valid)
ae = nn.Sequential(nn.Linear(6, 8), nn.ReLU(), nn.Linear(8, 2),
                   nn.Linear(2, 8), nn.ReLU(), nn.Linear(8, 6)).to(device)
optimizer = torch.optim.Adam(ae.parameters(), lr=1e-3)
mse = nn.MSELoss()
best_value, best_state = float("inf"), None

for step in range(2):
    ae.train()
    noisy_train = corrupt(clean_train)  # 매 학습 step에는 새 noise
    optimizer.zero_grad(set_to_none=True)
    reconstruction = ae(noisy_train)
    assert reconstruction.shape == clean_train.shape == (32, 6)
    loss = mse(reconstruction, clean_train)  # 정답은 noisy_train이 아닙니다.
    assert torch.isfinite(loss)
    loss.backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in ae.parameters())
    optimizer.step()
    assert torch.equal(clean_train, clean_before)

    ae.eval()
    with torch.inference_mode():
        denoised_valid = ae(noisy_valid)
        assert torch.isfinite(denoised_valid).all()
        valid_denoise_mse = mse(denoised_valid, clean_valid).item()
    # 선택 기준: noisy 입력에서 clean을 복원한 validation MSE
    if valid_denoise_mse < best_value:
        best_value = valid_denoise_mse
        best_state = {k: v.detach().clone() for k, v in ae.state_dict().items()}
    print(f"step={step + 1} train_denoise_mse={loss.item():.6f} "
          f"valid_denoise_mse={valid_denoise_mse:.6f}")

assert best_state is not None
ae.load_state_dict(best_state)
ae.eval()
with torch.inference_mode():
    restored = ae(noisy_valid)
    assert restored.shape == (12, 6) and torch.isfinite(restored).all()
    chosen_denoise_mse = mse(restored, clean_valid).item()
    # 보조 진단 두 개. checkpoint 선택 기준과 혼동하지 않습니다.
    identity_mse = mse(noisy_valid, clean_valid).item()  # 입력을 그대로 돌려주는 baseline
    clean_recon_mse = mse(ae(clean_valid), clean_valid).item()  # clean → clean 복원
assert abs(chosen_denoise_mse - best_value) < 1e-7
print("선택 모델 noisy→clean MSE:", chosen_denoise_mse)
print("무처리 noisy 입력 baseline MSE:", identity_mse)
print("보조 진단 clean→clean MSE:", clean_recon_mse)
print("Denoising 연결 검사 통과: clean 보존·gradient·출력·선택 checkpoint")
```

### 해설과 재도전

실제로 사용할 입력에 잡음이 있다면 주된 검증도 `noisy_valid → clean_valid`로 해야 합니다. `clean_valid → clean_valid` 점수는 잡음 없는 입력을 얼마나 잘 보존하는지 확인하는 **별도의 보조 진단**입니다. 둘 다 MSE를 계산하더라도 측정하는 대상은 다릅니다. `noisy_valid → noisy_valid` MSE 역시 잡음 제거 성능을 재는 지표가 아닙니다.

위 손실은 모든 표본의 6개 특성에 걸쳐 계산한 평균 제곱오차입니다. 검증용 잡음은 고정하고 훈련용 잡음만 새로 만듭니다. 실제 데이터에 스케일러가 필요하다면 훈련 데이터로만 학습한 변환을 똑같이 적용한 뒤, 어떤 단위에서 잡음과 오차를 정의할지 정하세요. 실제 센서 오차와 무관하게 잡음을 키우거나 원래 신호를 훼손하는 변환을 무조건 추가하지는 않습니다.

재도전은 두 가지입니다. 먼저 정답을 `noisy_train`으로 잘못 바꾸면 학습 목표가 어떻게 달라지는지 설명하세요. 다음으로 충분히 학습한 뒤 선택한 모델의 `noisy→clean MSE`가 입력을 그대로 두었을 때의 오차보다 작은지 비교하세요. 두 번째 실험에서도 잡음 크기와 모델은 검증 데이터로 선택하고, 별도 테스트 데이터가 있다면 마지막에 한 번만 평가합니다.

두 번의 갱신 검사를 통과하면 **입력과 정답의 대응, 잡음 없는 원본의 보존, 유한한 기울기, 출력 형태, 최적 검증 체크포인트의 복원**이 올바르다는 뜻입니다. 학습이 아직 짧아 입력을 그대로 두는 것보다 오차가 클 수 있으며, 그 자체가 구현 오류는 아닙니다. **구현 조건을 검사하는 것과 실제 잡음 제거 성능을 확보하는 것은 별개**입니다. 잡음 제거 AE의 복원 오차를 곧바로 이상탐지의 정답 라벨이나 보정된 이상 확률로 해석해서도 안 됩니다.

참고: [PyTorch 공식 GAN 학습 튜토리얼](https://docs.pytorch.org/tutorials/beginner/dcgan_faces_tutorial.html). 위 코드는 원문의 이미지 예제를 복제한 것이 아니라 2차원 합성 입력으로 기울기가 의도한 대로 계산되는지 확인하는 독립 실습입니다.

# 02. Seq2Seq의 학습 입력과 독립 추론

교육자료를 바탕으로 확장한 내용이다. 16~18강의 학습 반복문, 21~22강의 입력 구간과 RNN 상태를 먼저 공부한다. 기존 23강의 어텐션 개념만으로는 인코더-디코더(encoder-decoder)를 혼자 구현하기 어렵다. 핵심은 디코더가 예측할 시점 t의 정답을 직접 입력받지 않는다는 점이다.

정답이 `[a,b,eos]`이면 훈련 시 디코더 입력은 `[bos,a,b]`처럼 한 칸 이동시킨다. 이처럼 이전 정답을 입력하는 방법을 티처 포싱(teacher forcing)라고 한다. 추론할 때는 정답이 없으므로 `[bos]`에서 시작해 직전 예측을 다음 입력으로 사용한다. `eos`가 나오거나 최대 길이에 도달하면 멈춘다. 학습과 추론의 입력 분포가 달라진다는 점도 기억한다.

아래 예제는 토큰 시퀀스의 형태와 기울기 전달을 점검한다. 작은 무작위 초기화 모델의 예측 내용이 맞는지는 검증하지 않는다.

```python
import torch
from torch import nn
from torch.nn import functional as F
from torch.nn.utils.rnn import pack_padded_sequence

PAD, BOS, EOS, VOCAB = 0, 1, 2, 12

class TinySeq2Seq(nn.Module):
    def __init__(self):
        super().__init__()
        self.embed = nn.Embedding(VOCAB, 8, padding_idx=PAD)
        self.encoder = nn.GRU(8, 10, batch_first=True)
        self.decoder = nn.GRU(8, 10, batch_first=True)
        self.head = nn.Linear(10, VOCAB)

    def encode(self, source, lengths):
        if (lengths <= 0).any() or (lengths > source.size(1)).any():
            raise ValueError("실제 길이는 1..T 사이여야 합니다")
        packed = pack_padded_sequence(self.embed(source), lengths.cpu(),
                                     batch_first=True, enforce_sorted=False)
        _, state = self.encoder(packed)
        return state

    def teacher_logits(self, source, lengths, target):
        state = self.encode(source, lengths)
        previous = torch.cat([
            torch.full_like(target[:, :1], BOS), target[:, :-1]
        ], dim=1)
        decoded, _ = self.decoder(self.embed(previous), state)
        return self.head(decoded)             # [B,U,VOCAB]

    @torch.no_grad()
    def generate(self, source, lengths, max_steps=6):
        if max_steps <= 0:
            raise ValueError("max_steps는 양수여야 합니다")
        self.eval()
        state = self.encode(source, lengths)
        token = torch.full((source.size(0), 1), BOS,
                           dtype=torch.long, device=source.device)
        finished = torch.zeros(source.size(0), dtype=torch.bool,
                               device=source.device)
        result = []
        for _ in range(max_steps):
            output, state = self.decoder(self.embed(token), state)
            scores = self.head(output[:, 0])
            scores[:, [PAD, BOS]] = float("-inf")
            next_token = scores.argmax(-1)
            next_token = torch.where(finished, PAD, next_token)
            result.append(next_token)
            finished = finished | next_token.eq(EOS)
            token = next_token[:, None]
            if finished.all():
                break
        return torch.stack(result, dim=1)

torch.manual_seed(13)
source = torch.tensor([[3, 4, 5], [6, 7, PAD]])
lengths = torch.tensor([3, 2])               # padding 후에도 실제 길이 보존
target = torch.tensor([[5, 4, 3, EOS], [7, 6, EOS, PAD]])
model = TinySeq2Seq()
model.train()
logits = model.teacher_logits(source, lengths, target)
assert logits.shape == (2, 4, VOCAB)
loss = F.cross_entropy(logits.transpose(1, 2), target, ignore_index=PAD)
assert torch.isfinite(loss)
loss.backward()
assert model.encoder.weight_ih_l0.grad is not None
prediction = model.generate(source, lengths) # target 인수가 전혀 없다
assert prediction.shape[0] == 2 and 1 <= prediction.shape[1] <= 6
assert prediction.dtype == torch.long
print("Seq2Seq 학습/독립 추론 계약 검사 통과")
```

`lengths`는 패딩을 넣기 전의 실제 길이다. 패딩을 넣어 길이 5로 저장했더라도 원래 길이가 2이면 2를 전달한다. 인코더의 압축 처리(packing)와 디코더 손실의 마스킹(masking)은 서로 다른 처리다. 인코더가 패딩을 무시해도 손실 계산에서 패딩을 제외하려면 `ignore_index` 또는 명시적 마스크가 필요하다. 정답 전체가 패딩이면 유효한 학습 원소가 없으므로 입력 단계에서 차단한다.

실습: 정답의 마지막 토큰만 바꾸었을 때, 그 토큰을 예측하는 시점까지 티처 포싱 방식의 디코더 입력은 왜 같아야 하는가? `generate`에 정답을 전달한다면 무엇을 의심해야 하는가?

<details><summary>해설 보기</summary>

시점 t의 입력에는 t−1 시점까지의 정답만 들어간다. t 시점의 정답을 같은 시점의 입력에 넣으면 모델이 예측할 정답을 직접 보게 된다. 독립적인 추론에서는 제공된 특성만 입력받아야 한다. 정답을 요구하는 API라면 실제 평가 때 이용할 수 있는 정보인지 먼저 확인한다.

</details>

# 03. SVD·PCA·고전 ML·군집 실습

## PCA를 SVD와 역변환까지 연결하기

선형대수와 차원 축소 개념을 보강하는 내용이다. 4강의 행렬곱, 9강의 PCA/LDA, 12강의 군집화를 먼저 공부한다. 이미지 생성과 대표 표본의 라벨을 전파하는 실험은 교육자료에 기반한 선택 심화 과정이다. PCA가 무엇을 보존하고 버리는지 직접 확인하면 분산 보존률을 예측 정확도로 오해하지 않게 된다.

중심화한 데이터 행렬 `Xc:[N,F]`의 축소형 SVD는 `Xc=UΣVᵀ`다. `r=min(N,F)`로 두면 `U:[N,r]`, `Σ:[r,r]`, `Vᵀ:[r,F]`이며 특이값은 음수가 아니다. 행렬의 계수(rank)가 작으면 특이값 일부는 0이다. `U`는 `XcXcᵀ`, `V`는 `XcᵀXc`의 고유벡터와 연결된다. 임의 정방행렬의 SVD가 그 행렬의 고유분해와 같다는 주장은 틀리다.

상위 k개의 오른쪽 특이벡터를 `V_k:[F,k]`로 모으면 좌표는 `Z=XcV_k`, 복원은 `X_hat=ZV_kᵀ+mean_train`이다. 표본 공분산의 주성분 분산은 `singular_value²/(N−1)`이며 N>1을 가정한다. PCA 좌표계에서 k-means 중심을 고른 뒤 역변환하면 원래 공간의 대표 패턴을 볼 수 있다. 이것은 학습한 대표점을 복원하는 실험이며, 새로운 사람의 이미지나 다양한 실제 사례를 생성한다고 보장하지는 않는다.

손계산: 중심화된 행렬 `[[−1,0],[1,0]]`의 첫 방향은 첫 축, 특이값은 `sqrt(2)`다. 표본분산은 2, 둘째 방향 분산은 0이다. k=1로 줄여 복원해도 정보 손실이 없다.

```python
import numpy as np

# 이미 train/valid로 구분된 독립 합성 데이터
train = np.array([[-2., 0.], [-1., 0.], [1., 0.], [2., 0.]])
valid = np.array([[3., 1.], [-3., -1.]])
mean = train.mean(axis=0)
centered = train - mean
u, singular, vt = np.linalg.svd(centered, full_matrices=False)
components = vt[:1]                    # [k,F] = [1,2]
z_train = centered @ components.T      # [N,k]
z_valid = (valid - mean) @ components.T
recon_train = z_train @ components + mean
recon_valid = z_valid @ components + mean
variance = singular**2 / (len(train) - 1)
assert np.allclose(recon_train, train)
assert z_valid.shape == (2, 1)
assert np.isclose(np.square(recon_valid - valid).mean(), 0.5)
assert np.isclose(variance.sum(), np.var(train, axis=0, ddof=1).sum())
print("PCA 복원 검사 통과", "valid MSE:", 0.5)
```

직접 풀 문제: 훈련 데이터에서 스케일러와 PCA를 학습하고 검증 데이터에는 변환만 적용하는 이유는? k를 늘릴수록 훈련 데이터의 복원 오차가 줄어도 이를 활용하는 후속 분류 성능이 반드시 높아지지는 않는 이유는? 위 예제에서 검증 데이터의 두 번째 좌표에 이상탐지에 필요한 정보가 있다면 k=1로 줄일 때 무엇을 잃는가?

<details><summary>해설 보기</summary>

검증 데이터의 분포로 축을 선택하면 모델 비교에 쓸 데이터가 전처리 학습에 섞인다. 분산 보존과 정답 예측은 목적이 다르므로 분산이 작은 방향도 예측에 중요할 수 있다. 예제의 k=1 투영은 두 번째 좌표를 전부 버리므로 그 좌표에 있는 구분 정보도 사라진다. 다만 원래 공간에서의 복원 오차를 이상 점수(anomaly score)로 쓰는 별도 설계에서는 버려진 방향의 오차를 측정할 수 있다.

</details>

## 라벨을 붙일 수 있는 표본 수가 제한된 경우의 군집 대표 표본

교육자료에 기반한 선택 심화 내용이며 공식 DS 필수 실기 항목은 아니다.

라벨이 일부에만 있는 경우 훈련 특성을 군집화한 뒤 각 중심에 가장 가까운 표본을 골라 사람이 라벨을 붙이는 실험을 할 수 있다. 같은 수의 표본을 무작위로 골라 라벨을 붙인 경우와 비교한다. 전체 훈련 정답을 사용한 모델은 라벨 수가 다르므로 같은 조건의 비교 대상이 아니라 참고용 상한으로 따로 표시한다.

대표 표본의 라벨을 같은 군집 전체에 전파하면 학습 표본이 늘지만, 군집 안에 여러 클래스가 섞여 있으면 잘못된 정답도 늘어난다. 중심에 가까운 표본이 항상 그 군집의 정답 라벨을 대표하는 것은 아니다. 대표점에서 가까운 표본에만 먼저 라벨을 전파하고 신뢰도에 따른 성능을 비교할 수 있다. 검증·테스트 라벨은 표본 선택이나 라벨 전파에 사용하지 않는다.

실습 조건: 훈련 데이터를 30개 군집으로 나누고 대표점 30개의 라벨만 공개한다. 무작위 표본 30개로 학습한 모델, 대표점 30개로 학습한 모델, 거리를 제한해 라벨을 전파한 모델을 같은 독립 검증 데이터에서 비교한다. 선택한 대표점이 중복되면 실제로 라벨을 확인한 고유 표본 수도 기록한다. 실루엣 점수(silhouette)는 군집이 기하학적으로 얼마나 분리되었는지 나타내며 라벨 예측 정확도를 대신하지 않는다.

## 고전 ML을 같은 검증 조건에서 직접 비교하기

이 절은 교육자료를 확장한 실습이다. scikit-learn으로 고전 머신러닝 모델을 비교하고, 신경망은 계속 PyTorch로 구현한다. 특정 모델이나 아래 실습 전체가 공식 필수 구현이라는 뜻은 아니다. 본강 8~13강의 스케일링, 특성 선택, PCA/LDA, 앙상블, 검증을 먼저 공부한다.

모델 이름을 아는 것과 새 데이터에서 모델들을 공정하게 비교하는 것은 다르다. 이 실습에서는 원자료의 분할을 먼저 고정한 뒤 전처리와 모델을 하나의 Pipeline으로 묶는다. 교차검증(CV)은 각 폴드(fold)에서 Pipeline을 새로 학습하므로 평균·표준편차·PCA 축·LDA 축·선택할 특성을 검증 폴드에서 배우지 않는다.

이 합성 데이터는 각 행이 독립적인 표형 데이터라고 가정한다. 실제 데이터가 같은 차량의 반복 관측이거나 시간순 자료라면 아래의 무작위 층화 분할을 그대로 적용하지 말고 그룹 또는 시간순 분할을 설계한다.

### 데이터 구성과 모델의 입력·출력 조건

데이터는 540행이며 수치 특성 12개와 클래스 3개로 구성된다. 먼저 최종 테스트 108행을 따로 두고, 나머지에서 검증 108행을 분리한다. 훈련 324행 내부에서 같은 3개 폴드로 교차검증하여 후보를 비교한다. 이 실습의 검증 데이터는 선택한 모델을 독립적으로 점검하는 용도이며 다시 후보를 고르는 데 사용하지 않는다. 최종 선택을 확정하면 훈련·검증 데이터를 합쳐 재학습하고 테스트를 한 번만 평가한다. 실제 작업에서 검증 결과를 보고 다시 수정했다면 그 검증 점수는 더 이상 최종 일반화 성능의 독립적인 증거가 아니다.

PCA/LDA는 원래 특성을 새 좌표로 바꾸고, SelectFromModel은 원래 특성 중 일부만 남긴다. 클래스가 3개이면 LDA가 만드는 축은 최대 2개다. 아래 특성 선택에 쓰는 랜덤 포레스트(Random Forest)는 특성 중요도를 얻기 위한 고전 머신러닝 모델이며 별도의 신경망을 사용하지 않는다.

### 독립 실행 예제

```python
import time
import numpy as np
from sklearn.base import clone
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.feature_selection import SelectFromModel
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier, VotingClassifier
from sklearn.metrics import f1_score

started = time.perf_counter()
X, y = make_classification(
    n_samples=540, n_features=12, n_informative=6, n_redundant=2,
    n_classes=3, n_clusters_per_class=1, weights=[0.55, 0.30, 0.15],
    class_sep=1.0, random_state=23,
)
# 인위적으로 단위를 다르게 하되 target은 전처리에 사용하지 않는다.
X *= np.logspace(0, 2, X.shape[1])
all_ids = np.arange(len(y))
dev_ids, test_ids = train_test_split(
    all_ids, test_size=0.2, stratify=y, random_state=23,
)
train_ids, valid_ids = train_test_split(
    dev_ids, test_size=0.25, stratify=y[dev_ids], random_state=24,
)
assert not (set(train_ids) & set(valid_ids))
assert not (set(dev_ids) & set(test_ids))
assert (len(train_ids), len(valid_ids), len(test_ids)) == (324, 108, 108)

knn = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=7))
svm = make_pipeline(StandardScaler(), SVC(C=1.0, gamma="scale"))
models = {
    "scaled KNN": knn,
    "scaled SVM": svm,
    "PCA + KNN": make_pipeline(
        StandardScaler(), PCA(n_components=6), KNeighborsClassifier(7)),
    "LDA + KNN": make_pipeline(
        StandardScaler(), LinearDiscriminantAnalysis(n_components=2),
        KNeighborsClassifier(7)),
    "selected + KNN": make_pipeline(
        StandardScaler(),
        SelectFromModel(RandomForestClassifier(n_estimators=24, random_state=23),
                        threshold="median"),
        KNeighborsClassifier(7)),
    "bagged tree": BaggingClassifier(
        estimator=DecisionTreeClassifier(max_depth=5),
        n_estimators=8, random_state=23),
    "hard voting": VotingClassifier(
        estimators=[("knn", knn), ("svm", svm),
                    ("tree", DecisionTreeClassifier(max_depth=5, random_state=23))],
        voting="hard"),
}
folds = list(StratifiedKFold(n_splits=3, shuffle=True, random_state=25).split(
    X[train_ids], y[train_ids]))
means = {}
for name, model in models.items():
    scores = cross_val_score(model, X[train_ids], y[train_ids], cv=folds,
                             scoring="f1_macro", error_score="raise")
    assert scores.shape == (3,) and np.isfinite(scores).all()
    means[name] = scores.mean()
    print(f"{name:16s} CV mean={scores.mean():.3f}, std={scores.std():.3f}")

chosen = max(means, key=means.get)  # 선택에는 train 내부 CV만 사용
selected = clone(models[chosen]).fit(X[train_ids], y[train_ids])
valid_pred = selected.predict(X[valid_ids])
assert valid_pred.shape == y[valid_ids].shape
print("CV로 고정한 모델:", chosen)
print("valid Macro-F1:", f1_score(y[valid_ids], valid_pred, average="macro"))

# 여기까지 선택을 고정한 뒤 마지막 평가를 한 번 수행한다.
final_model = clone(models[chosen]).fit(X[dev_ids], y[dev_ids])
test_pred = final_model.predict(X[test_ids])
print("final test Macro-F1:", f1_score(y[test_ids], test_pred, average="macro"))
print(f"총 실행 시간: {time.perf_counter() - started:.2f}초")
```

실습을 변형할 때는 위 코드의 테스트 출력 부분을 잠시 빼 두고 훈련 데이터 내부의 교차검증이나 검증 데이터로만 결정한다. 마지막 테스트 점수를 이미 확인한 데이터를 계속 사용하면 ‘한 번만 평가’ 원칙을 지킬 수 없다. 추가 연습에서는 새 난수 시드(seed)로 테스트 데이터를 다시 만들고 최종 단계까지 보지 않는다.

### 결과를 읽는 법

교차검증 평균은 같은 분할에서 얻은 세 폴드 점수의 평균이다. 표준편차는 폴드 사이의 변동을 보여 주지만 세 폴드만으로 엄밀한 신뢰구간을 구할 수는 없다. 후보를 많이 비교해 가장 높은 점수를 고르면 그 최고점도 낙관적일 수 있다. 표준편차가 작다는 이유만으로 좋은 모델이라고 판정하지 않는다.

배깅(Bagging)은 같은 종류의 트리를 부트스트랩(bootstrap) 표본에서 여러 번 학습한다. 보팅(Voting)은 서로 다른 종류의 모델이 예측한 클래스를 투표로 합친다. 이 예제는 클래스 라벨을 사용하는 하드 보팅(hard voting)이므로 SVM의 확률 추정이 필요 없다. 확률을 사용하는 소프트 보팅(soft voting)으로 바꾸려면 모든 구성 모델의 확률 출력과 클래스별 열 순서를 확인해야 한다.

PCA가 분산을 많이 보존하거나 랜덤 포레스트가 중요하다고 판단한 특성을 남겼다고 해서 KNN 성능이 반드시 좋아지지는 않는다. PCA·LDA·특성 선택을 거치면 거리 계산에 쓰는 좌표와 남은 정보가 달라지므로 실제 평가지표로 어떤 변환이 도움이 되는지 비교한다. 합성 데이터 한 번의 비교에서 가장 좋았던 모델이 실제 자동차 데이터에서도 가장 좋다고 일반화하지 않는다.

### 직접 바꾸어 풀기

1. PCA 차원을 6에서 3으로 바꿀 때 학습 시간이 줄고 성능이 달라지는 이유를 설명하라. LDA도 3으로 바꾸어도 되는가?
2. 데이터 분할 전에 `SelectFromModel`을 전체 X,y로 학습한 뒤 이 코드를 실행하면 왜 누수인가?
3. KNN에서 StandardScaler를 제거한 후보를 추가하라. 단위가 100배 다른 특성이 거리 계산에 어떤 영향을 주는지 예측한 뒤 확인하라.
4. 선택한 모델을 훈련·검증 데이터를 합쳐 재학습했다면 검증 점수를 다시 계산해 ‘최종 일반화 성능’이라고 부를 수 있는가?
5. 보팅의 성능이 가장 좋지 않아도 코드가 틀렸다는 뜻은 아닌 이유를 설명하라.

<details><summary>해설 보기</summary>

1. PCA 출력이 `[N,3]`이 되어 거리 계산량은 줄지만 정답 예측에 유용한 방향도 버릴 수 있다. 3클래스 LDA의 일반적인 축 수 상한은 2이므로 3축 설정은 맞지 않는다.
2. 검증·테스트 정답을 보고 특성을 선택했기 때문이다. 교차검증 폴드를 나누어도 이미 선택된 열에 정답 정보가 반영되어 낙관적인 평가가 된다.
3. 유클리드 거리에서는 각 특성의 차이를 제곱한다. 단위만 100배 커져도 해당 항은 10,000배 커져 다른 특성보다 훨씬 큰 영향을 줄 수 있다. 실제 영향은 값의 분포와 정보량에도 달려 있다.
4. 재학습에 검증 데이터가 들어갔으므로 그 점수는 훈련 성능의 일부다. 최종 평가는 아직 학습·선택에 쓰지 않은 테스트 데이터로 한다.
5. 구성 모델들의 오류가 비슷하거나 약한 모델의 투표가 강한 모델의 올바른 예측을 바꾸면 성능이 개선되지 않을 수 있다. 앙상블을 사용한다고 성능 향상이 보장되지는 않는다.

</details>

## 군집 실행과 실루엣 점수를 계산할 수 없는 경우

교육자료에 기반한 선택 실습이다. 군집화는 정답 라벨 없이 특성의 구조를 찾는다. DBSCAN의 잡음 라벨 −1을 실제 클래스로 해석하지 않으며, 잡음을 반드시 제거해야 하는 데이터 오류라고 단정하지도 않는다. 아래 코드는 같은 특성을 K-means와 DBSCAN으로 탐색하고 **잡음을 제외한 군집의 실루엣 점수**와 전체 잡음 비율을 따로 보고한다.

이 예제는 주어진 데이터 전체의 군집 구조를 살피는 탐색 분석이며, 새로운 테스트 데이터의 예측 성능을 평가하는 실험은 아니다. 군집에서 얻은 특성을 분류기 입력으로 쓰려면 앞 절처럼 훈련 폴드에서만 스케일러와 군집 모델을 학습해야 한다.

```python
import numpy as np
from sklearn.datasets import make_moons
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, DBSCAN
from sklearn.metrics import silhouette_score

def summarize_clusters(X, labels):
    labels = np.asarray(labels)
    keep = labels != -1
    n = int(keep.sum())
    k = len(np.unique(labels[keep]))
    noise_ratio = float((~keep).mean())
    # silhouette는 평가 표본에 군집이 2개 이상, 표본수보다 적게 있어야 한다.
    score = silhouette_score(X[keep], labels[keep]) if 2 <= k < n else None
    return {"clusters": k, "noise_ratio": noise_ratio,
            "silhouette_without_noise": score}

X, _ = make_moons(n_samples=240, noise=0.06, random_state=31)
X = StandardScaler().fit_transform(X)
for name, model in (
    ("k-means", KMeans(n_clusters=2, n_init=10, random_state=31)),
    ("DBSCAN", DBSCAN(eps=0.30, min_samples=5)),
):
    report = summarize_clusters(X, model.fit_predict(X))
    assert 0 <= report["noise_ratio"] <= 1
    print(name, report)

# 전부 noise와 단일 군집에서는 점수를 만들지 않는 계약을 검사한다.
all_noise = DBSCAN(eps=0.01, min_samples=len(X)+1).fit_predict(X)
assert summarize_clusters(X, all_noise)["silhouette_without_noise"] is None
assert summarize_clusters(X, np.zeros(len(X), dtype=int))[
    "silhouette_without_noise"] is None
print("군집 퇴화 조건 검사 통과")
```

실루엣의 `a`는 같은 군집의 다른 표본까지 평균거리다. `b`는 다른 군집 각각까지 평균거리를 구한 뒤 그중 가장 작은 값이다. 다른 군집의 중심점까지 거리와는 다르다. 곡선형 군집은 눈으로 의미 있게 구분되어도 유클리드 거리로 계산한 실루엣 점수가 기대보다 낮을 수 있다. DBSCAN 후보마다 제외되는 잡음의 비율이 다르므로 이 점수만 비교하면 쉬운 표본만 남긴 후보를 고를 수 있다. 잡음 비율과 실제 분석 목적도 함께 고려한다.

직접 풀 문제: eps를 0.10과 0.60으로 바꾸어 군집 수와 잡음 비율을 관찰하라. 실루엣 점수가 가장 큰 eps를 무조건 고르면 안 되는 이유는? DBSCAN 결과가 모두 −1이면 −1을 하나의 일반 군집으로 간주해 점수를 계산해도 되는가?

<details><summary>해설 보기</summary>

eps가 작으면 이웃이 부족해 잡음이 늘기 쉽고, 크면 군집이 합쳐질 수 있다. 정확한 변화는 데이터에 따라 다르다. 후보마다 평가에 남는 표본이 다르거나 실제 의미와 맞지 않는 군집이 만들어질 수 있으므로 점수만 최적화하지 않는다. 모두 −1이면 이 실습의 정의상 군집에 배정된 표본이 없다. 실루엣의 정의 조건도 만족하지 않으므로 억지로 점수를 출력하지 않는다.

</details>

참고: [Pipeline과 전처리 누수 예방](https://scikit-learn.org/1.5/common_pitfalls.html), [공식 앙상블 안내](https://scikit-learn.org/1.5/modules/ensemble.html), [PCA 문서](https://scikit-learn.org/1.5/modules/generated/sklearn.decomposition.PCA.html). 교육자료 확장 실습이며 모델 선택 권고나 실기 출제 보장이 아닙니다.

# 04. 베이즈 탐색·기대 개선량·실험 보고

교육자료의 개념을 확장한 내용이다. 6강의 확률, 13강의 검증, 15강의 탐색·실험 설계를 먼저 공부한다. 외부 튜닝 도구나 특정 패키지를 공식 시험에서 요구한다고 해석하지 않는다. 모델 한 번의 학습에 오래 걸릴 때 다음 실험을 고르는 원리를 이해하기 위한 강의다.

하이퍼파라미터(hyperparameter) 조합마다 실제 모델을 학습하는 비용이 크면, 지금까지 평가한 조합과 검증 점수로 목적함수를 근사할 수 있다. 이렇게 만든 근사 모델을 대리 모델(surrogate)이라고 한다. 가우스 과정(Gaussian Process, GP)이 대표적이지만 모든 베이즈 탐색 도구가 GP를 사용하는 것은 아니다. 근사 평균은 기대 성능을, 불확실성은 아직 충분히 살펴보지 못한 정도를 나타낸다.

획득 함수(acquisition function)는 기대 성능과 불확실성을 이용해 다음에 실제로 평가할 후보를 고른다. 현재 성능이 좋은 곳 주변을 더 살피는 활용(exploitation)과 불확실한 곳을 살피는 탐색(exploration)을 함께 고려한다. 획득 함수의 점수가 높다고 검증 성능이 확인된 것은 아니다. 후보를 실제로 학습·검증한 뒤 대리 모델을 갱신한다.

점수가 클수록 좋은 문제에서 현재 최고 실측 점수를 `f_best`라 하면 개선량은 `max(f(x)−f_best−ξ,0)`, 기대 개선량(Expected Improvement, EI)은 그 기대값이다. GP 예측이 평균 μ, 표준편차 σ인 정규분포라면 σ>0에서 `z=(μ−f_best−ξ)/σ`, `EI=(μ−f_best−ξ)Φ(z)+σφ(z)`다. σ=0에서는 결정적 개선량을 직접 계산한다. 오차를 최소화하는 문제에서는 부호와 최적값의 정의를 바꿔야 한다.

탐색 실습에서는 데이터 분할·평가지표·평가 횟수와 시간을 같게 두고 격자 탐색(grid search)과 무작위 탐색(random search)을 먼저 비교한다. 3×4×2 조합을 5개 폴드로 평가하면 격자 탐색에는 120번의 학습이 필요하다. 무작위 후보 8개를 5개 폴드로 평가하면 40번이다. 최종 재학습 비용은 별도다. PyTorch 실험마다 모델과 옵티마이저를 새로 만들고 최적 체크포인트를 저장한다. 마지막에 실행한 모델이 가장 좋은 설정의 모델이라고 착각하지 않는다. 시간이 촉박하면 모델 하나와 핵심 하이퍼파라미터 몇 개에만 집중하는 편이 현실적이다.

```python
from math import erf, exp, isclose, pi, sqrt

def expected_improvement(mu, sigma, best, xi=0.0):
    """점수 최대화 문제의 단일 후보 EI. Gaussian surrogate 가정."""
    if sigma < 0:
        raise ValueError("표준편차는 음수일 수 없습니다")
    improvement = mu - best - xi
    if sigma == 0:
        return max(improvement, 0.0)
    z = improvement / sigma
    cdf = 0.5 * (1.0 + erf(z / sqrt(2.0)))
    density = exp(-0.5 * z*z) / sqrt(2.0*pi)
    return max(improvement * cdf + sigma * density, 0.0)

assert isclose(expected_improvement(0.8, 0.0, 0.7), 0.1)
assert expected_improvement(0.6, 0.0, 0.7) == 0.0
assert isclose(expected_improvement(0.7, 0.1, 0.7), 0.1/sqrt(2*pi))
# 같은 평균이라면 아직 불확실한 후보에도 개선 가능성이 있다.
assert expected_improvement(0.7, 0.1, 0.7) > expected_improvement(0.7, 0, 0.7)
print("EI 경계값·손계산 검사 통과")
```

이 코드는 획득 함수의 수치만 계산하며 GP 학습이나 완전한 베이즈 최적화 알고리즘을 구현한 것은 아니다. 검증 정확도는 범위가 제한된 값이므로 정규분포를 사용하는 대리 모델도 근사라는 점을 기억한다.

직접 풀 문제: μ=best, σ=0이면 EI는 얼마인가? RMSE를 그대로 ‘maximize’로 넣으면 어느 방향으로 탐색하는가? 실험마다 검증 데이터를 다르게 나누면 후보 비교에 어떤 변동이 추가되는가?

<details><summary>해설 보기</summary>

첫 답은 0이다. 불확실성이 없고 예측값이 현재 최고 점수와 같아 개선량이 없다. RMSE를 최대화하면 오차가 큰 후보를 선호하므로 최소화로 설정하거나 음의 RMSE를 최대화해야 한다. 분할이 바뀌면 하이퍼파라미터의 효과와 데이터 난도 차이가 섞인다. 비교 목적에 맞게 분할을 고정하거나 같은 교차검증 폴드를 사용한다.

</details>

## 학습 결과 보고서의 최소 기록

교육자료 DOCX에서 요구하는 실험·결과·한계 설명을 독립 학습지로 재구성한 항목이다. 기존 15강의 요소별 비교 실험표에 다음 내용을 함께 적으면 결과를 다시 검토하기 쉽다.

- 데이터 구성: 행·그룹·시간의 단위, 정답의 의미와 단위, 실제로 사용할 수 있는 특성
- 정제 근거: 결측·이상치를 오류 또는 유효한 신호로 판단한 이유
- 검증 근거: 분할 방식, 누수 검사, 클래스·그룹 분포
- 비교 조건: 바꾼 요소 하나, 고정한 요소, 난수 시드, 시간·메모리 한도
- 결과: 검증 지표, 클래스·정답 항목별 오류, 사용한 체크포인트
- 한계: 합성 데이터와 실제 데이터의 차이, 누락된 관측, 일반화할 수 없는 조건

빈칸에 점수만 적고 끝내지 않는다. 예를 들어 ‘RMSE가 줄었다’에 더해 어떤 정답 항목과 기간에서 개선되었는지, 선택한 분할이 실제 배포 상황을 어떻게 반영하는지 설명한다.
